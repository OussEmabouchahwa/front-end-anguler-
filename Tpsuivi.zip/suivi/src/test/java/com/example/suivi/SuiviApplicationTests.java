package com.example.suivi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuiviApplicationTests {

	@Test
	void contextLoads() {
	}

}
